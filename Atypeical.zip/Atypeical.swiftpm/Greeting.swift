import SwiftUI

struct Greeting: View {
    var modes = AtypeicalModes();
    
    var body: some View {
        VStack(spacing: 24) {
            VStack {
                Text("Welcome to Atypeical!")
                    .font(.largeTitle)
                Text("This is a simple yet engaging typing speed test built for a variety of users.")
                    .font(.title2)
                    .foregroundColor(.secondary)
            }
            
            Text("To get started, just select a mode from the sidebar, click the bottom textbox, and start typing!.")
                .font(.body)
            
            VStack(spacing: 12) {
                Text("Which mode is right for me?")
                    .font(.title3)
                    .multilineTextAlignment(.center)
                ForEach(modes.modes) { mode in
                    VStack(spacing: 12) {
                        Text(mode.name)
                            .font(.title2)
                            .bold()
                            .frame(maxWidth: .infinity, alignment: .leading)
                            .foregroundColor(mode.color)
                        Text(mode.description)
                            .font(.headline)
                            .frame(maxWidth: .infinity, alignment: .leading)
                    }
                    .frame(width: 500)
                    .padding(20)
                    .background(.regularMaterial, in: RoundedRectangle(cornerRadius: 12))
                }
            }
        }
    }
}

struct Greeting_Previews: PreviewProvider {
    static var previews: some View {
        Greeting()
    }
}
