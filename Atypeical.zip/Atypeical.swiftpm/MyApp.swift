import SwiftUI

@main
struct MyApp: App {
    var body: some Scene {
        WindowGroup {
            NavigationView {
                ModeNav()
                    .navigationTitle("Mode Selection")
                    .navigationBarBackButtonHidden(true)
                    .listStyle(SidebarListStyle())
                Greeting()
            }
        }
    }
}
