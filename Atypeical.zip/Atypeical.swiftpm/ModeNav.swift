import SwiftUI

struct ModeNav : View {
    var modes = AtypeicalModes();
    
    var body : some View {
        List() {
            ForEach(modes.modes) { mode in
                NavigationLink {
                    StandardMode(mode: mode)
                } label: {
                    ModeCard(mode: mode)
                }
            }
        }
    }
}
