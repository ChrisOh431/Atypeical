import SwiftUI
import Charts

struct Results: View {
    var wordMan : WordManager;
    var statMan : StatManager;
    var mode: AtypeicalMode;
    
    var WPM : Int;
    var CPS : Int;
    var accuracy : Double;
    var formattedAcc : Int;
    var totChars : Int;
    let percentFormatter : NumberFormatter = NumberFormatter();
    
    init(mode: AtypeicalMode, wordMan: WordManager, statMan: StatManager) {
        self.WPM = 0;
        self.CPS = 0;
        self.accuracy = 0.0;
        self.formattedAcc = 0;
        self.totChars = 0;
        self.mode = mode;
        self.wordMan = wordMan;
        self.statMan = statMan;
        
        self.WPM = calcWPM();
        self.CPS = calcCPS();
        self.accuracy = calcAcc();
        self.formattedAcc = Int(100 * self.accuracy);
        self.totChars = calcTotChars();
        
        for charsec in statMan.cps {
            charsec.calcWPM();
        }
        
        percentFormatter.numberStyle = .percent;
        percentFormatter.maximumIntegerDigits = 3;
        percentFormatter.maximumFractionDigits = 2;
    }
    
    let columnLayout = Array(repeating: GridItem(), count: 3)
    
    var body: some View {
        VStack(alignment: .center, spacing: 30) {
            if #available(macCatalyst 16.0, *) {
                VStack {
                    Text("WPM Over \(statMan.totalTime) Seconds")
                        .font(.title)
                    Chart(statMan.cps, id: \.secondOfInput) { second in
                        LineMark(
                            x: .value("Second", second.secondOfInput),
                            y: .value("WPM", second.WPM)
                        )
                        .foregroundStyle(mode.color)
                        .interpolationMethod(.catmullRom)
                        
                        RuleMark(y: .value("Overall WPM", WPM))
                            .foregroundStyle(.foreground)
                            .annotation(position: .top, alignment: .leading) {
                                Text("Overall: \(WPM) WPM")
                                    .font(.body)
                                    .foregroundStyle(.foreground)
                            }
                    }
                    .frame(width: 600, height: 400)
                }   
            }
            
            HStack (spacing: 24) {
                VStack {
                    Text("\(WPM)")
                        .font(.title)
                        .foregroundColor(.primary)
                    Text("Words/Minute")
                        .font(.body)
                        .foregroundColor(.secondary)
                }
                .frame(width: 160, height: 90)
                .padding(10)
                .background(.background, in: RoundedRectangle(cornerRadius: 12))
                
                VStack {
                    Text("\(CPS)")
                        .font(.title)
                        .foregroundColor(.primary)
                    Text("Characters/Second")
                        .font(.body)
                        .foregroundColor(.secondary)
                }
                .frame(width: 160, height: 90)
                .padding(10)
                .background(.background, in: RoundedRectangle(cornerRadius: 12))
                
                VStack {
                    Text("\(formattedAcc)%")
                        .font(.title)
                        .foregroundColor(.primary)
                    Text("Accuracy")
                        .font(.body)
                        .foregroundColor(.secondary)
                }
                .frame(width: 160, height: 90)
                .padding(10)
                .background(.background, in: RoundedRectangle(cornerRadius: 12))
            }
            
            VStack {
                Text("Word Log")
                    .font(.title)
                ScrollView {
                    LazyVGrid(columns: columnLayout) {
                        ForEach(wordMan.completedWords) { word in
                            Text("\(word.word)")
                                .font(.title3)
                                .foregroundColor(word.correct ? .green : .red)
                                .frame(minHeight: 20)
                        }
                    }
                    .padding(20)
                }
            }
        }
    }
    
    func calcWPM() -> Int {
        var totalChars = 0;
        
        for charsec in statMan.cps {
            totalChars += charsec.correctCharCnt;
        }
        
        let charsPerSec : Double = Double(totalChars) / Double(statMan.totalTime);
        let charsPerMin = charsPerSec * 60;
        let WPM = charsPerMin / 5;
        
        return Int(WPM);
    }
    
    func calcCPS() -> Int {
        var totalChars = 0;
        
        for charsec in statMan.cps {
            totalChars += charsec.correctCharCnt;
        }
        
        let charsPerSec : Double = Double(totalChars) / Double(statMan.totalTime);
        
        return Int(charsPerSec);
    }
    
    func calcAcc() -> Double {
        var totalChars : Int = 0;
        var totalCorrect : Int = 0;
        
        for charsec in statMan.cps {
            totalChars += charsec.charCnt;
            totalCorrect += charsec.correctCharCnt;
        }
        
        let acc : Double = Double(totalCorrect) / Double(totalChars);
        
        return acc;
    }
    
    func calcCPS() {
        for charsec in statMan.cps {
            charsec.calcWPM();
        }
    }
    
    func calcTotChars() -> Int {
        var totalChars : Int = 0;
        
        for charsec in statMan.cps {
            totalChars += charsec.charCnt;
        }
        
        return totalChars;
    }
}
