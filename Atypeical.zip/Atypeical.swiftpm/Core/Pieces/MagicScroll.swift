import SwiftUI

struct MagicScroll: View {
    @EnvironmentObject var wordMan : WordManager;
    @EnvironmentObject var statMan : StatManager;
    
    init() {
        UITextView.appearance().backgroundColor = .clear;
        UITextView.appearance().showsVerticalScrollIndicator = false;
        UITextField.appearance().focusEffect  = .none;
    }
    
    var body: some View {
        VStack(alignment: .center, spacing: 24) {
            Runes(completedWords: wordMan.completedWords, wordList: wordMan.currentWordList, inputString: wordMan.inputString, remainderString: wordMan.remainderString, wordError: wordMan.wordError)
                .frame(maxWidth: 500, minHeight: 80, alignment: .center)
                .fixedSize()
                .clipped()
                .background(RoundedRectangle(cornerRadius: 15)
                    .shadow(color: .black, radius: 12)
                    .foregroundColor(.black)
                    .opacity(0.1))
        }
        .frame(maxWidth: 800, maxHeight: 65)
    }
}
