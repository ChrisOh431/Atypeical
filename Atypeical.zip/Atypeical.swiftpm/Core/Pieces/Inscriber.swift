import SwiftUI

struct Inscriber: View {
    @EnvironmentObject var wordMan : WordManager;
    @EnvironmentObject var statMan : StatManager;
    
    var body: some View {
        TextField("Type here.", text: $wordMan.inputString)
            .autocorrectionDisabled()
            .frame(minWidth: 100, maxWidth: 300, minHeight: 70, alignment: .leading)
            .font(.title)
            .multilineTextAlignment(.center)
            .background(.background, in: RoundedRectangle(cornerRadius: 12))
            .onChange(of: wordMan.inputString) { newValue in
                if (!statMan.testStarted) {
                    statMan.testStarted = true;
                    statMan.testFinished = false;
                }
                
                if (wordMan.inputString == " ")
                {
                    // space was typed, no word,
                    // do nothing.
                    wordMan.inputString = "";
                    return;
                }
                else if (!wordMan.inputString.isEmpty && wordMan.inputString.firstIndex(of: " ") != nil)
                {
                    // space was typed
                    // and a word exists, move on to the next
                    wordMan.inputString.removeLast();
                    
                    wordMan.moveOn();
                    return;
                }
                
                if (wordMan.inputString.last == " ") {
                    return;
                }
                
                wordMan.updateRemainder(newValue);
                if (!wordMan.bsped) {
                    // ignore backspaces
                    if (!wordMan.wordError) {
                        statMan.logChar(correct: true);
                    }
                    else {
                        statMan.logChar(correct: false);
                    }
                }
                else {
                    wordMan.bsped = false;
                }
                
                if (wordMan.currentWordList.isEmpty && wordMan.inputString == wordMan.currentWord.word) {
                    wordMan.moveOn();
                    statMan.testStarted = false;
                    statMan.testFinished = true;
                }
            }
    }
}
