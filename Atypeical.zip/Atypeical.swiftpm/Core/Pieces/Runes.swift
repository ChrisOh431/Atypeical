import SwiftUI

struct Runes: View {
    var completedWords : [Word];
    var wordList : [Word];
    var inputString : String;
    var remainderString : String;
    var wordError : Bool;
    
    var body: some View {
        HStack(spacing: 1.5) {
            LazyHStack(spacing: 8) {
                ForEach(completedWords) {
                    wordObj in Text(wordObj.word)
                        .font(.largeTitle)
                        .foregroundColor(wordObj.correct ? .green : .red)
                        .fixedSize()
                }
                
                Text(inputString)
                    .font(.largeTitle)
                    .foregroundColor(!wordError ? .green : .red)
                    .fixedSize()
            }
            .frame(width: 300, alignment: .trailing)
            
            Rectangle()
                .foregroundColor(.primary)
                .frame(width: 3, height: 50, alignment: .center)
            
            LazyHStack(spacing: 8) {
                Text(remainderString)
                    .font(.largeTitle)
                    .fixedSize()
                
                ForEach(wordList) {
                    wordObj in Text(wordObj.word)
                        .font(.largeTitle)
                        .fixedSize()
                }
            }
            .frame(width: 300, alignment: .leading)
        }
    }
}
