import SwiftUI

class Word : Identifiable {
    var id = UUID();
    var word : String;
    var correct = true;
    
    init(word: String, correct: Bool = true) {
        self.word = word;
        self.correct = correct;
    }
}

class WordManager : ObservableObject {
    @Published var currentWord : Word = Word(word: "");
    
    @Published var currentWordList : [Word] = [];
    @Published var completedWords : [Word] = [];
    
    @Published var inputString = "" {
        willSet {
            if (newValue < inputString) {
                bsped = true;
            }
        }
    };
    var bsped = false;
    
    @Published var remainderString = "";
    var lastRemaining = "";
    
    @Published var wordError = false;
    
    let dicty : Encyclo = Encyclo();
    var seedString = "Standard";
    
    init(seedstring: String)
    {
        self.seedString = seedstring;
        var arr = dicty.wordStrings[seedstring]!.components(separatedBy: " ");
        
        arr.shuffle();
        
        currentWord = Word(word: arr.first ?? "");
        arr.removeFirst();
        
        currentWordList = arr.map {(string) -> Word in Word(word: string) };
        remainderString = wordCompare(str1: inputString, str2: currentWord.word);
        lastRemaining = remainderString;
    }
    
    func reset() {
        self.currentWord = Word(word: "");
        self.currentWordList = [];
        self.completedWords = [];
        self.inputString = "";
        self.bsped = false;
        
        var arr = dicty.wordStrings[self.seedString]!.components(separatedBy: " ");
        
        arr.shuffle();
        
        currentWord = Word(word: arr.first ?? "");
        arr.removeFirst();
        
        currentWordList = arr.map {(string) -> Word in Word(word: string) };
        remainderString = wordCompare(str1: inputString, str2: currentWord.word);
        lastRemaining = remainderString;
        
        wordError = false;
    }
    
    func updateRemainder(_ newVal: String) {
        remainderString = wordCompare(str1: newVal, str2: currentWord.word);
        wordError = wordIsInError(str1: newVal, str2: currentWord.word);
    }
    
    func checkProperCharacterEntered() -> Bool {
        // remainder string shrunk + word
        // isn't in error
        if (remainderString.count < lastRemaining.count) {
            lastRemaining = remainderString;
            return true;
        }
        
        return false;
    }
    
    func moveOn() {
        // space was entered
        completedWords.append(Word(word: inputString, correct: (inputString == currentWord.word) ? true : false));
        inputString = "";
        
        if let firstElement = currentWordList.first {
            // after removing the first word
            // there's another one to move onto
            currentWord = firstElement;
            currentWordList.removeFirst();
            lastRemaining = currentWord.word;
        }
        else
        {
            // no more words after removing that one
            currentWord = Word(word: "");
            lastRemaining = "";
            remainderString = "";
        }
    }
}
