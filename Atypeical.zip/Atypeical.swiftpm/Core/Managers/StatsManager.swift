import SwiftUI

struct TestResults {
    var totalTime: Int;
    var cps : [Charsec];
    var completedWords : [Word];
}

class Charsec : Identifiable {
    var secondOfInput : Int = 0;
    var charCnt = 0;
    var correctCharCnt = 0;
    var WPM : Double = 0;
    var id = UUID();
    
    init(secondOfInput: Int) {
        self.secondOfInput = secondOfInput
    }
    
    func calcWPM() {
        let totWords : Double = Double(correctCharCnt) / 5;
        let timeRatio : Double = 1 / 60;
        
        let secWPM : Double = totWords / timeRatio;
        self.WPM = secWPM;
    }
    
    func incChar(correct: Bool) {
        charCnt += 1;
        if (correct) {
            correctCharCnt += 1;
        }
    }
}

class StatManager : ObservableObject {
    @Published var cps : [Charsec];
    @Published var testStarted : Bool;
    @Published var testFinished : Bool;
    
    var maxTime = 30;
    @Published var totalTime : Int;
    
    init() {
        cps = [Charsec(secondOfInput: 0)];
        
        totalTime = 0;
        
        testStarted = false;
        testFinished = false;
    }
    
    func calcWPM() -> Double {
        var totalChars = 0;
        
        for charsec in cps {
            charsec.calcWPM();
            totalChars += charsec.charCnt;
        }
        
        let charsPerSec : Double = Double(totalChars) / Double(totalTime);
        let charsPerMin = charsPerSec * 60;
        let WPM = charsPerMin / 5;
        
        return WPM;
    }
    
    func logChar(correct: Bool) {
        cps.last?.incChar(correct: correct);
    }
    
    func incTime() {
        totalTime += 1;
        cps.append(Charsec(secondOfInput: totalTime));
    }
    
    func reset() {
        self.cps = [];
        self.testStarted = false;
        self.testFinished = false;
        self.totalTime = 0;
    }
}
