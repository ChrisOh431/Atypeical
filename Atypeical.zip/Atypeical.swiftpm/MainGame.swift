import SwiftUI

struct StandardMode : View {
    var mode : AtypeicalMode;
    
    @StateObject var wordMan : WordManager;
    @StateObject var statMan : StatManager = StatManager();
    
    @State private var timer: Timer?;
    @State private var timeLeft : Double = 30;
    @State private var maxTime : Double = 30;
    @State private var isRunning = false;
    
    init(mode: AtypeicalMode = AtypeicalMode(name: "Standard", description: "The regular mode.", gameDesc: "The regular mode.", color: .white)) {
        self.mode = mode;
        _wordMan = StateObject(wrappedValue: WordManager(seedstring: mode.name));
        self.timer = timer;
        self.timeLeft = timeLeft;
        self.maxTime = maxTime;
        self.isRunning = isRunning;
    }
    
    var body : some View {
        if statMan.testFinished {
            ZStack {
                mode.color
                    .ignoresSafeArea()
                    .opacity(0.05)
                VStack(spacing: 12) {
                    Button(action: {
                        timer?.invalidate();
                        
                        self.timeLeft = 30;
                        self.maxTime = 30;
                        self.isRunning = false;
                        
                        statMan.reset();
                        wordMan.reset();
                    }) {
                        Text("Play Again")
                            .font(.title)
                            .buttonStyle(.borderedProminent)
                            .foregroundColor(mode.color)
                    }
                    .disabled(isRunning && wordMan.completedWords.count < 1)
                    .opacity((isRunning && wordMan.completedWords.count < 1) ? 0 : 1)
                    .padding([.leading, .trailing], 15)
                    .padding([.top, .bottom], 10)
                    .background(
                        RoundedRectangle(cornerRadius: 12)
                            .fill(.background)
                            .opacity((isRunning && wordMan.completedWords.count < 1) ? 0 : 1)
                    )
                    .frame(width: 800)
                    
                    Results(mode: mode, wordMan: wordMan, statMan: statMan);
                }
            }
        }
        else {
            ZStack {
                mode.color
                    .ignoresSafeArea()
                    .opacity(0.05)
                VStack(spacing: 24) {
                    VStack {
                        Text(mode.name)
                            .font(.largeTitle)
                            .bold()
                            .foregroundColor(mode.color)
                            .opacity(0.9)
                        Text(mode.gameDesc)
                            .font(.headline)                        
                    }
                    .opacity((statMan.testStarted) ? 0 : 1)
                    
                    ProgressView(value: timeLeft, total: maxTime) { Text("Time Remaining:") }
                        .frame(maxWidth: 500)
                        .progressViewStyle(LinearProgressViewStyle(tint: mode.color.opacity(0.75)))
                    
                    MagicScroll()
                        .environmentObject(wordMan)
                        .environmentObject(statMan)
                    
                    Inscriber()
                        .environmentObject(wordMan)
                        .environmentObject(statMan)
                    
                    Button(action: {
                        timer?.invalidate();
                        statMan.testStarted = false;
                        statMan.testFinished = true;
                    }) {
                        Text("End Test")
                            .foregroundColor(mode.color)
                    }
                    .disabled(isRunning && wordMan.completedWords.count < 1)
                    .opacity((isRunning && wordMan.completedWords.count < 1) ? 0 : 1)
                    .padding([.leading, .trailing], 15)
                    .padding([.top, .bottom], 10)
                    .background(
                        RoundedRectangle(cornerRadius: 12)
                            .fill(.background)
                            .opacity((isRunning && wordMan.completedWords.count < 1) ? 0 : 1)
                    )
                    .frame(width: 200, height: 50)
                }
                .onAppear() {
                    startTimer();
                }
                .onDisappear {
                    timer?.invalidate();
                    isRunning = false;
                }
            }
        }
    }
    
    private func startTimer() {
        isRunning = true;
        
        timer = Timer.scheduledTimer(withTimeInterval: 1, repeats: true) { _ in
            if (statMan.testStarted) {
                if timeLeft > 0 {
                    timeLeft -= 1;
                    statMan.incTime();
                } else {
                    timer?.invalidate();
                    
                    isRunning = false;
                    statMan.testStarted = false;
                    statMan.testFinished = true;
                }
            }
        }
    }
}
