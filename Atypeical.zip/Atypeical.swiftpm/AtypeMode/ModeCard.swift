import SwiftUI

struct ModeCard: View {
    var mode : AtypeicalMode;
    
    var body: some View {
        ZStack {
            RoundedRectangle(cornerRadius: 14)
                .frame(maxHeight: 45)
                .foregroundColor(mode.color)
            Text(mode.name)
                .bold()
                .font(.title3)
                .foregroundColor(.white)
                .multilineTextAlignment(.center)
        }
        .frame(minHeight: 65)
    }
}

struct ModeCard_Previews: PreviewProvider {
    static var previews: some View {
        HStack {
            ModeCard(mode: AtypeicalMode(name: "Test", description: "This is for testing!", gameDesc: "What a test!", color: .brown))
            ModeCard(mode: AtypeicalMode(name: "Test", description: "This is for testing!", gameDesc: "What a test!", color: .blue))
            ModeCard(mode: AtypeicalMode(name: "Test", description: "This is for testing!", gameDesc: "What a test!", color: .green))
        }
    }
}
