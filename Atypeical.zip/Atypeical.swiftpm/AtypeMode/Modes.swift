import Foundation
import SwiftUI

struct AtypeicalMode : Identifiable {
    let name: String;
    let description: String;
    let gameDesc: String;
    let color: Color;
    
    let id : UUID = UUID();
}

class AtypeicalModes {
    var modes = [
        AtypeicalMode(name: "Beginner", description: "A calm mode with shorter and easier words, this is the best for those who want the simplest typing experience.", gameDesc: "Easy words with no capitalization or punctuation.", color: .purple),
        AtypeicalMode(name: "Standard", description: "The standard configuration. With puntuation and short-medium length words, this is the day-to-day typing experience made fun.", gameDesc: "Common words with punctuation and capitals.", color: .blue),
        AtypeicalMode(name: "Coding", description: "Write lots of code? This mode is for you. Test your coding skills by writing keywords in Swift and View names in SwiftUI.", gameDesc: "Swift keywords and SwiftUI Views.", color: .green)
    ]
}
